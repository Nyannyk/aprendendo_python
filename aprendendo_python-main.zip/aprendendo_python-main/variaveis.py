nome = "Alice" # STRING OU STR(texto)
idade = 30 #int inteiro
altura = 1.75 #Float  decimal
eh_ativa = True #Bool booleano

