contador = 0

while contador < 5:
    print(f'Contador esta em {contador}')
    contador = contador + 1
    contador+=1