def somar(numero1, numero2):
    resultado_soma = numero1 + numero2
    
    print(resultado_soma)
    
    return resultado_soma

somar(2, 3)
resultado_da_soma = somar(2, 3 )
print(resultado_da_soma)

print(f"Somando 7 e 2 diretaente: {somar(7,2)}")