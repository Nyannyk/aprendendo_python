def apresentar_pet(nome_animal, tipo_animal):
    print(f"Este é o {nome_animal}!, ele é um {tipo_animal} muito esperto")
    
apresentar_pet("Rex", "cachorro")
apresentar_pet("Miau","gato")
apresentar_pet("AUur", "Lobo")
    