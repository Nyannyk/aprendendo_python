#Laço de repetição FOR


for i in range(5):
    print(f"Repeticao do numero {i}")

