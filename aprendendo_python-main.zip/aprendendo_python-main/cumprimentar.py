def cumprimentar_pessoa(nome):
    print(f"Olá, {nome}! Tudo bem com você?")
    
cumprimentar_pessoa("Maria")
cumprimentar_pessoa("Jonas")
cumprimentar_pessoa("Johnny")
cumprimentar_pessoa("Erik")
    
    