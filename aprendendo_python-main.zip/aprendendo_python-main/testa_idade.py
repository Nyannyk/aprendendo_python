#esse é um comentário de 1 linha 
"""
comentários de multiplas linhas 

"""
#verificar se o usuário é maior de idade 

idade = 18
if idade >=18:
    print("maior de idade") 
else:
    print(" menor de idade") 
