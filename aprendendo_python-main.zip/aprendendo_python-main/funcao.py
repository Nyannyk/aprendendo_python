def saudacao():
    print("Oioi")
    